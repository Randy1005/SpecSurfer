﻿using tainicom.Aether.Physics2D.Dynamics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Diagnostics;
using System.Net.Mime;
using Microsoft.Xna.Framework.Content;

namespace SpectrumSurfer
{
    class Global
    {
        public static ContentManager content;
        public static SpriteBatch _spriteBatch;
        public static GraphicsDeviceManager _graphics;
        public static BasicEffect _spriteBatchEffect;
        public static SpriteFont _font;
    }
}
